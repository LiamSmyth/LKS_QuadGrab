"""util – shared helper modules for lks_quadgrab."""
